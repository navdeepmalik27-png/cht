package com.overcast.mini;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restore the opt-in weather indicator after reboot or app upgrade. */
public final class WeatherBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction())) {
            if (WeatherPrefs.isTemperatureBadgeEnabled(context)) {
                WeatherJobService.schedulePeriodic(context);
                WeatherStatusManager.sync(context);
            }
            NewsJobService.schedule(context);
            WeatherTileService.requestRefresh(context);
        }
    }
}
