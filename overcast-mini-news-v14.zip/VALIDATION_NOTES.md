# Overcast Mini v1.4 validation notes

Checked in this environment:
- Source integration: all six news category IDs, feed URLs, and publisher labels.
- Android resources: 36 XML resource/manifest documents parsed successfully; 69 Java `R.id` references resolve to declared resource IDs.
- Offline Java 11 compilation of `NewsCategories` and `NewsFeedClient` against lightweight Android API test stubs, with tests for domain validation, six category bits, fairness, duplicate removal, and 24-item cap.
- `build_min_apk.sh` shell syntax and GitHub Actions YAML syntax.

NOT checked: full Android SDK APK compilation, Open-Meteo and RSS calls from device, Android 12+/OxygenOS widget interaction, and signing continuity. These require a GitHub build/device test. The official Indian Express RSS directory documents the three selected feeds, but some direct automated attempts to fetch those feeds were blocked with 403 from the research environment. The app handles feed failures and keeps its previous cached items.

Publisher terms: The Indian Express states on https://indianexpress.com/rss/ that its RSS feeds are for personal/non-commercial consumption. The app only stores headlines, categories, dates and source URLs and opens original articles through the browser; it does not bypass publisher subscriptions or redistribute full article text.
