# Overcast Mini v1.7 - Frosted Glass

## Changes

- Only ONE current-condition icon is drawn in front of the glass background, beside the temperature. It has a translucent rimmed foreground plate (`bg_glass_icon_plate.xml`). The background has no discrete sun or moon glyph, resolving the duplicate shown in v1.6.
- All six widgets retain their original IDs and click interactions. The glass background is drawn first in each widget's FrameLayout; all information, including the condition icon, is overlaid afterwards.
- Fifteen weather-reactive backdrops, including fog, snow, rain, thunderstorms and day/night variations, now use smoky translucent layered gradients, highlights, faint texture and rounded glass edges.
- Readability: glass-mode layouts use fixed high-contrast text colors regardless of the phone's Material You day/night theme; the RSS flipper collection rows are styled in code too.
- The news strip uses a translucent dark panel instead of a whitish overlay that could obscure text.
- Background scenes are pre-rendered images, updated with cached Open-Meteo weather (no additional polling, location tracking or battery-heavy animations).

## Important platform limitation

These are **frosted-glass simulations**, not real-time wallpaper blur. An Android RemoteViews home-screen widget cannot generally blur arbitrary content from the launcher behind it. Individual launchers may also apply their own shape/clipping and scaling. Tested source resources do not guarantee identical rendering on OxygenOS.

## Foreground icon order

`glass_scene` ImageView is the **first child** of the root FrameLayout and therefore underneath all content; `news_weather_icon` / `iv_icon` are in the later foreground content layout, with legible current temperature in the same horizontal row. No second background weather icon exists.
