## v1.7 Frosted Glass / Icon readability update

The current weather icon remains **foreground, directly beside the temperature**, never behind it. Glass weather scenes are decorative light/fog/rain/star atmospheres without an additional sun/moon graphic in the temperature area. v1.7 contains all v1.6 functionality. Set **Frosted Glass** in the app settings. See `GLASS_THEME_GUIDE.md`.

# Overcast Mini v1.6 | Full-headline widget + Frosted Glass

**New:** The Weather + News widget gives the headline the entire card width underneath the source header, with up to three text lines and no redundant section or publisher caption inside individual headline rows. Publisher attribution stays in the header and in the in-app reader.

**Frosted Glass setting:** In the app, switch **Frosted Glass widgets** on/off. The six widgets immediately redraw from cached data, retaining click actions and weather functions. Off uses the original opaque Material-style cards. On uses a translucent illustrated rounded background with a frosted inner panel for the news and forecast widgets. All widget backgrounds support light/dark device themes.

Atmospheric scenes: sunny clear day, partial clouds, overcast, rain, fog, snow, thunderstorm; nighttime counterparts show the moon, stars where visibility allows, and weather effects. If weather data is unknown or older than six hours, a neutral frosted backdrop is used. Scenes follow the existing Open-Meteo update interval (and can change a little later than actual sunrise/sunset due to Doze). No animated wallpaper or additional weather requests.

**Technical limitation:** Android launcher `RemoteViews` cannot generally sample and apply real-time blur to the wallpaper behind widgets. This is an intentionally **simulated frost / translucent weather illustration**, not platform wallpaper-blur. Legibility on very high-contrast wallpaper may vary.

**Install:** Upload `overcast-mini-news-v16-glass.zip` to the root of the `cht` GitHub repo, then replace `.github/workflows/build.yml` with the included `build.yml`, commit, and run **Build Overcast Mini APK**. Download artifact `overcast-mini-news-v16-apk` when successful. If upgrading without uninstalling, use the same signing key as the installed v1.5 APK.

---

# Overcast Mini — Weather, AQI, Sky Arcs, News & Quick Settings

A zero-dependency Android widget pack styled after the open-source **[Overcast](https://github.com/sameerasw/overcast)** Material 3 Expressive design language and powered by the free **[Open-Meteo API](https://open-meteo.com/en/docs)** (no API key required).

## Lightweight by Design (vs. ~6.75 MB full app)
- **Zero external libraries**: Pure Java 11 + Android Framework SDK only (no Kotlin stdlib, no Jetpack Compose, no AndroidX, no Material library, no OkHttp, no Gson, no WorkManager).
- **Native Material 3 Expressive Dynamic Color**: Uses Android 12+ system dynamic color tokens (`@android:color/system_accent1_*`, `@android:color/system_neutral1_*`) directly in XML (`values-v31` / `values-night-v31`) with matching Overcast dark/light tonal fallbacks for Android 8–11.
- **Minimal Vector Icons**: 8 geometric `VectorDrawable` XMLs (~250 bytes each) covering all WMO weather codes.

## Battery-Saving Architecture
- **No background GPS / location polling**: Saves coordinates once via Open-Meteo Geocoding or an optional one-shot cached coarse location (`NETWORK_PROVIDER` / `PASSIVE_PROVIDER`).
- **Doze-friendly `JobScheduler`**: Batches updates with OS network windows (`NETWORK_TYPE_ANY`, `setRequiresBatteryNotLow(true)`, configurable 1h / 2h / 3h / 6h interval, `updatePeriodMillis="0"`).
- **Compact gzipped payloads**: Requests the next eight hourly weather records, two days of sunrise/sunset, and a small separate AQI response. Both are cached for all widget types.
- **Zero wake locks, zero foreground services, 30s tap-to-refresh debounce**.

## Widgets Included
1. **Overcast · Compact (2×2+)**: Expressive rounded card (`28dp` radius), location pill, rain probability pill, oversized display temperature (`50sp` bold), crisp vector weather icon, condition + H/L temperatures.
2. **Overcast · Forecast Pill (4×2+)**: Adds a nested Material 3 Expressive tonal inner card (`20dp` radius) showing the next 4 hourly forecast slots.
3. **Overcast · Air Quality (2×2+)**: Current **US AQI** category, PM2.5/PM10 in µg/m³, and the age of the cached report. Category colors follow the US AQI scale. Uses **Open-Meteo / CAMS modelled concentrations**, not a nearby physical monitor and **not** India's CPCB AQI scale.
4. **Overcast · Precipitation (4×2+)**: Next-six-hour precipitation estimate in mm, highest hourly probability, and six color bars showing rain chance (local hourly timestamps).
5. **Overcast · Sun & Moon (4×3+)**: A visual **24-hour sky arc** (amber sun trajectory, blue dashed moon trajectory, and a NOW marker). The curves show altitude above/below the horizon, **not compass directions**. Shows sunrise, sunset, moonrise, moonset, moon phase, and illumination. Solar/lunar positions and lunar rise/set times are calculated **locally** every ~30 minutes. Sunrise/sunset uses Open-Meteo when today's local data is available. No navigation-grade accuracy is claimed.

6. **Overcast · Weather + Selective News (4×2+)**: A weather-and-news widget with live cached current temperature, condition and city, plus rotating **The Hindu + The Indian Express** attributed headlines. Tap any headline to read its original article in your browser; tap **READ NEWS ↗** to open the app's headline library. Other five widgets are unchanged.

### Selective RSS news + full-article links (v1.5)
The app has **six independently selectable news sections**:

| Publisher | Section in app | RSS feed |
| --- | --- | --- |
| The Hindu | Science | `https://www.thehindu.com/sci-tech/science/feeder/default.rss` |
| The Hindu | World | `https://www.thehindu.com/news/international/feeder/default.rss` |
| The Hindu | Top Stories | `https://www.thehindu.com/feeder/default.rss` |
| The Indian Express | Explained | `https://indianexpress.com/section/explained/feed/` |
| The Indian Express | Banking & Finance | `https://indianexpress.com/section/business/banking-and-finance/feed/` |
| The Indian Express | Economy & Policy | `https://indianexpress.com/section/business/economy/feed/` |

- All sections are selected by default. When upgrading from v1.3, existing The Hindu selections are preserved and new Indian Express sections are enabled the first time; if the user turned every section off, they remain off. Any combination is allowed. The Hindu **Top Stories** is its website home feed and **not** verified print Page One coverage. Indian Express **Economy & Policy** displays the publisher's official *Economy* RSS section and is not a separate Policy feed.
- The news widget rotates up to **24** cached, deduplicated headlines and labels each with its true **publisher and section**. Headlines are interleaved fairly so a high-volume feed doesn't monopolize the widget. Individual RSS feed failures do not prevent other sections refreshing.
- **Open and read full articles:** Tap a headline directly on the widget to launch the corresponding publisher webpage in the phone's browser. Tap **READ NEWS ↗** in the widget, or **Browse headlines · Read full articles ↗** in app settings, to view a scrolling list of cached headlines; each has a **Read full article ↗** button. That screen can manually refresh RSS even without a news widget installed.
- This app does **not** copy articles or bypass paywalls. If a story requires a login/subscription, the publisher controls access. Article links are verified to be HTTPS URLs within `thehindu.com` or `indianexpress.com` (including subdomains). No API key, third-party RSS SDK, JavaScript renderer or embedded browser is required.
- While a news widget exists and at least one section is enabled, `JobScheduler` requests RSS updates approximately every 30 minutes, subject to Android battery restrictions. The app caches titles, attribution category, timestamps and canonical links only; nothing is pulled from RSS when every category is deselected. Weather requests are separate and continue as before.
- **Publisher reachability:** The three Indian Express RSS URLs are listed in its official directory, but automated fetch attempts from this environment returned HTTP 403/blocked responses for some feeds. A phone-side fetch may behave differently; the reader keeps cached headlines when a source fails. Verify feeds on the actual device.
- **Publishing rights:** The Indian Express's official [RSS page](https://indianexpress.com/rss/) states that its feeds are for **personal and non-commercial use**. Do not publish a syndicated-news app or distribute publisher content commercially without reviewing terms and obtaining required permission. The browser opening original article pages does not give a license to republish their full text.

## Quick Settings Weather Tile + Opt-in Status Bar Weather Icons
- **Android 8+**: Native swipe-down `Weather` Quick Settings toggle. Its label includes the cached current temperature, e.g. `Weather 27°C`. The tile displays a condition/temperature icon from the set supplied by the user.
- **Indicator ON**: Posts **one quiet ongoing notification**. The left-hand status-bar symbol changes between nine supplied weather illustrations, using white/transparent small icon assets at 24/36/48/72/96 px for Android density scaling. The **colored original artwork** appears as the enlarged notification icon when supported. The notification text also includes current temperature, condition, and city.
- **Indicator OFF**: Cancels the notification immediately. Removing the Quick Settings tile also disables the indicator. There is a `Turn off` action in the notification. It restores the enabled state after reboot where Android permits.
- **No extra network calls**: The symbols update when the existing shared weather cache is refreshed (1/2/3/6-hour user-selected schedule), or when the tile is toggled. An indicator with a stale/unavailable forecast switches to a generic mild icon and states that weather is unavailable instead of showing a falsely fresh reading.
- **Permission**: Android 13+ requires `Allow notifications`; disabling the app's weather notification channel also hides the indicator.
- **Add the tile**: Open Overcast Mini and choose `Add Weather Quick Settings tile` (Android 13+ confirmation prompt) or swipe down twice → Edit tiles → add the Weather tile manually.
- **Android limitation**: Android notification **small icons are monochrome**, usually tinted white or dark by the OS; the uploaded colors **cannot appear in the status bar** without OS-specific privileges. The enlarged colored image appears in the notification drawer. Exact placement next to the time is controlled by OxygenOS and **cannot be guaranteed**. Official references: [Android system bars](https://developer.android.com/design/ui/mobile/guides/foundations/system-bars) and [Notification.Builder.setSmallIcon](https://developer.android.com/reference/android/app/Notification.Builder#setSmallIcon(int)).

### Status-bar artwork mapping
The images received here were named `10001558xx.png`/`.jpg` by the upload system, so their original temperature-range filenames **were not available**. These are editable defaults, implemented in `WeatherStatusIcons.choose()`:

| Priority / temperature in °C | Status-bar artwork |
| --- | --- |
| Thunderstorm/hail (WMO 95–99), any temperature | Gray storm cloud with rain and lightning |
| Rain/drizzle/showers (WMO 51–67 or 80–82), any temperature | Blue rain cloud |
| Any other weather, ≤ 0°C | Guy with meter / bundled-up person |
| 1–7°C | Two snowflakes |
| 8–13°C | One snowflake |
| 14–20°C | Sun and cloud |
| 21–27°C | Simple thermometer |
| 28–33°C | Simple thermometer (chosen warm fallback for the unspecified slot) |
| 34–38°C | Guy sweating |
| ≥ 39°C | Red hot flame icon |

Weather condition has precedence over temperature for heavy rain and thunderstorms. Thresholds are always converted to Celsius internally if Fahrenheit units are selected. Since no separate night-specific original was supplied, normal/mild nights reuse the same sun-and-cloud illustration. Only one condition is shown at a time.


## How to Build the APK

### Option 1: Direct Android SDK build (requires Android SDK + JDK 11+)
```bash
chmod +x build_min_apk.sh
./build_min_apk.sh
# Output: build_min/overcast-mini-widget.apk
```

### Option 2: Zero Local Setup (GitHub Actions)
Push this folder to a GitHub repository -> open the **Actions** tab -> run **Build Overcast Mini APK** -> download `overcast-mini-news-v15-apk`. An Android SDK build runner is required; the source ZIP itself is not an installable APK.

### Option 3: Android Studio / Gradle
Open this folder in Android Studio and run **Build -> Generate Signed App Bundle / APK** (or `./gradlew assembleRelease`).

## How to Use
1. Install the built APK, then long-press your Android home screen and open **Widgets**.
2. Choose any of the six **Overcast Mini** widgets. Place it on the home screen.
3. Set the city by name or use a cached coarse location, then save. **All six widgets and the Weather Quick Settings tile share one chosen weather location.** Tap the location label on a widget to change it.
4. Tap the card to request a weather/AQI refresh. The AQI and precipitation widgets use the same battery-friendly scheduled update interval as the original weather widgets.
5. Open the app and add the Quick Settings Weather tile. Swipe down to toggle the status-bar temperature on/off. On Android 13+, allow notifications when requested.

## Data & Accuracy
- Forecasts, rainfall, sunrise/sunset: [Open-Meteo Forecast API](https://open-meteo.com/en/docs).
- Modelled air quality: [Open-Meteo Air Quality API](https://open-meteo.com/en/docs/air-quality-api), powered by [Copernicus Atmosphere Monitoring Service (CAMS)](https://atmosphere.copernicus.eu/). **US AQI is not directly interchangeable with India CPCB AQI; neither should be mistaken for nearby station readings.**
- Sun/moon sky arc: offline approximate solar/lunar ephemeris. The chart plots elevation against the chosen city's local time (not azimuth/compass), and the moonrise/moonset labels are approximate. The lunar position omits high-accuracy corrections (parallax, perturbation series, and atmospheric refraction), so expect errors of several minutes or more for rise/set and a few degrees for positions. Use a precise astronomy app for observations/navigation.
- The sky-arc chart redraws at Android's ~30-minute widget interval. Android may delay updates during Doze/battery saver; positions are not continuously animated. If forecast timezone information isn't cached yet, the chart temporarily falls back to the device's own timezone until forecast data loads.
- Network-dependent widgets show placeholders until a city is chosen and data are fetched. AQI reports older than six hours are visibly labelled as stale, not passed off as live measurements.

## Resource Notes
No new dependencies. The tiny rain and sky illustrations are rendered into low-resolution bitmap charts only when a widget updates. The nine user-supplied status bar glyphs are pre-rendered white/alpha PNG resources; no dynamic bitmaps or extra CPU work are required to produce the notification icon. No foreground services or ongoing location polling.

### Build/test status
The source ZIP is ready for the included Android SDK CLI / GitHub Actions build, but **no actual device or full Android SDK compilation was available in the editing environment**. XML resources and pure-Java sky calculations were validated; verify OxygenOS status-bar icon rendering and tile add flows on the target device.

### Weather + News update notes
- Add the **Overcast · Weather + Selective News** widget from the home-screen widget picker. Choose Science, World and/or Top Stories in app settings for automatic cycling (where supported by your launcher).
- RSS updates are separate from the weather schedule. The weather icon/temperature and quick-settings/status-bar functionality continue using the existing Open-Meteo cache.
- The source archive is named `overcast-mini-news-v15.zip`; use the accompanying `build.yml` in `.github/workflows/` when the repository stores only that ZIP (as in your existing GitHub setup).
- For updating an APK already installed on your phone, retain the same signing keystore. The included minimal build script generates an ephemeral debug key by default, so APKs built in separate runs may require uninstall/reinstall, which can remove saved local widget settings. For reproducible signing in future builds, configure GitHub Actions repository secrets `OVERCAST_KEYSTORE_B64`, `OVERCAST_KEYSTORE_PASS`, `OVERCAST_KEY_ALIAS`, optionally `OVERCAST_KEY_PASS`, using a securely stored private keystore. Never commit the keystore/private key to a public repository. A newly chosen key cannot update an app previously signed with a different key.

## News quality + bookmarks (v1.5)
- The RSS reader now takes each item's **direct** `<title>` field only. Embedded image/Media RSS `<title>` fields no longer replace it; IDs such as `IMG20261119110655` or `bank_a09b26` are rejected.
- Only plausible headlines from the last **5 days** are shown in the Latest feed, which also filters the old cached content from v1.4. Other publisher sections remain selectable.
- Open **READ NEWS** to switch between **Latest** and **Saved**, then tap **☆ Save** / **★ Saved** beside an article. Saved titles, source, publication date and original HTTPS URL are stored locally (max 200), stay available when the headline falls out of the news feed, and are never copied as full article text.
- Reading articles still opens the original publisher website, subject to its subscription policies. No offline article bodies, tracking SDKs, or article scraping.
- Bookmarks survive app upgrades that retain app data and signing identity, but are lost if Android uninstalls the app or app data are cleared (`allowBackup=false`).
- **Live-feed limitation:** Published RSS sources may return old or malformed entries and may block requests. When no fresh items are available, the widget displays a no-recent-news message instead of silently showing stale/false headlines.
