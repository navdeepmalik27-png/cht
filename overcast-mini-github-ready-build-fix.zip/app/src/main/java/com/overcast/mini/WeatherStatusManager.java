package com.overcast.mini;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Icon;
import android.os.Build;

/**
 * A user-controlled weather notification. Android decides how its small icon
 * appears in the status bar; no direct status-bar modification is attempted.
 */
public final class WeatherStatusManager {
    // Keep existing channel/ID so upgrading doesn't leave a duplicate indicator.
    public static final String CHANNEL_ID = "temperature_indicator_v1";
    private static final int NOTIFICATION_ID = 2001;
    private static final long MAX_AGE_MS = 24L * 60 * 60 * 1000;

    private WeatherStatusManager() { }

    public static boolean canNotify(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || !nm.areNotificationsEnabled()) return false;
        return Build.VERSION.SDK_INT < 33
                || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static void sync(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (!WeatherPrefs.isTemperatureBadgeEnabled(context) || !WeatherPrefs.hasLocation(context)
                || !canNotify(context)) {
            nm.cancel(NOTIFICATION_ID);
            return;
        }
        NotificationChannel channel = nm.getNotificationChannel(CHANNEL_ID);
        if (channel == null) {
            channel = new NotificationChannel(CHANNEL_ID, "Weather status-bar icon",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows one condition/temperature icon while Weather Quick Settings is on.");
            channel.setShowBadge(false);
            nm.createNotificationChannel(channel);
        } else {
            // Preserve the user's importance/permission choice while updating the label.
            channel.setName("Weather status-bar icon");
            channel.setDescription("Shows one condition/temperature icon while the Weather tile is on.");
            nm.createNotificationChannel(channel);
        }
        if (channel.getImportance() == NotificationManager.IMPORTANCE_NONE) {
            nm.cancel(NOTIFICATION_ID);
            return;
        }

        WeatherData data = WeatherData.parse(WeatherPrefs.getCachedJson(context));
        long age = System.currentTimeMillis() - WeatherPrefs.getLastUpdatedMs(context);
        boolean valid = data != null && age >= 0 && age < MAX_AGE_MS;
        WeatherStatusIcons.Kind kind = valid
                ? WeatherStatusIcons.choose(data.wmoCode, data.temp, WeatherPrefs.isFahrenheit(context))
                : WeatherStatusIcons.Kind.MILD_CLOUD_SUN;
        int smallIcon = WeatherStatusIcons.smallIcon(kind);
        int largeIcon = WeatherStatusIcons.colorArtwork(kind);
        String unit = WeatherPrefs.isFahrenheit(context) ? "°F" : "°C";
        String detail = valid
                ? WeatherData.conditionLabel(data.wmoCode) + " · " + WeatherPrefs.getCity(context)
                : "Weather unavailable or out of date · Tap to update location";

        Intent config = new Intent(context, ConfigActivity.class);
        config.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent configPi = PendingIntent.getActivity(context, 211, config,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent disable = new Intent(context, WeatherBadgeReceiver.class);
        disable.setAction(WeatherBadgeReceiver.ACTION_OFF);
        PendingIntent offPi = PendingIntent.getBroadcast(context, 212, disable,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder notification = new Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(smallIcon)
                .setLargeIcon(Icon.createWithResource(context, largeIcon))
                .setContentTitle(valid ? (data.temp + unit + " · Current weather") : "Weather is unavailable")
                .setContentText(detail)
                .setContentIntent(configPi)
                .addAction(new Notification.Action.Builder((Icon) null, "Turn off", offPi).build())
                .setCategory(Notification.CATEGORY_STATUS)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setShowWhen(false)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setAutoCancel(false);
        try {
            nm.notify(NOTIFICATION_ID, notification.build());
        } catch (RuntimeException ignored) {
            // Some OEM builds can block notifications even after permission checks.
        }
    }
}
