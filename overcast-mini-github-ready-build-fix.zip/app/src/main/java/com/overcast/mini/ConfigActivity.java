package com.overcast.mini;

import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.app.StatusBarManager;
import android.content.ComponentName;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

/**
 * Minimal Material 3 Expressive widget configuration screen.
 * Uses Open-Meteo Geocoding API (no API key) or one-shot cached coarse location.
 */
public final class ConfigActivity extends Activity {
    private static final int REQ_COARSE = 42;
    private static final int REQ_NOTIFICATIONS = 43;
    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private EditText etCity;
    private Switch swFahrenheit;
    private RadioGroup rgInterval;
    private TextView tvStatus;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);
        setContentView(R.layout.activity_config);

        Intent intent = getIntent();
        if (intent != null && intent.getExtras() != null) {
            widgetId = intent.getExtras().getInt(
                    AppWidgetManager.EXTRA_APPWIDGET_ID,
                    AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        etCity = findViewById(R.id.et_city);
        swFahrenheit = findViewById(R.id.sw_fahrenheit);
        rgInterval = findViewById(R.id.rg_interval);
        tvStatus = findViewById(R.id.tv_status);
        btnSave = findViewById(R.id.btn_save);
        Button btnGps = findViewById(R.id.btn_last_loc);

        etCity.setText(WeatherPrefs.getCity(this));
        swFahrenheit.setChecked(WeatherPrefs.isFahrenheit(this));

        int iv = WeatherPrefs.getIntervalMinutes(this);
        if (iv <= 60) rgInterval.check(R.id.rb_1h);
        else if (iv <= 120) rgInterval.check(R.id.rb_2h);
        else if (iv <= 180) rgInterval.check(R.id.rb_3h);
        else rgInterval.check(R.id.rb_6h);

        btnGps.setOnClickListener(v -> useLastKnownCoarseLocation());
        btnSave.setOnClickListener(v -> saveAndFinish());
        findViewById(R.id.btn_add_weather_tile).setOnClickListener(v -> addQuickSettingsTile());
        findViewById(R.id.btn_notification_permission).setOnClickListener(
                v -> requestNotificationPermission());
        updateIndicatorStatus();
        if (getIntent().getBooleanExtra(WeatherTileService.EXTRA_REQUEST_NOTIFICATIONS, false)
                && !WeatherStatusManager.canNotify(this)) {
            // Launched from a user tap on the Quick Settings tile.
            btnSave.post(this::requestNotificationPermission);
        }
    }

    private void useLastKnownCoarseLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{ Manifest.permission.ACCESS_COARSE_LOCATION }, REQ_COARSE);
            return;
        }
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        Location loc = null;
        if (lm != null) {
            loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (loc == null) loc = lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
        }
        if (loc == null) {
            tvStatus.setText("No cached location yet. Enter a city name instead.");
            return;
        }
        WeatherPrefs.saveLocation(this, "My Location", loc.getLatitude(), loc.getLongitude());
        etCity.setText("My Location");
        applySettingsAndFetch();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_COARSE && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
            useLastKnownCoarseLocation();
        } else if (code == REQ_NOTIFICATIONS) {
            WeatherStatusManager.sync(this);
            updateIndicatorStatus();
            tvStatus.setText(WeatherStatusManager.canNotify(this)
                    ? "Weather icon enabled. Use the Quick Settings tile to toggle it."
                    : "Notification permission denied. Enable Overcast Mini notifications in Android settings to show the weather icon.");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (findViewById(R.id.tv_indicator_state) != null) updateIndicatorStatus();
    }

    private void updateIndicatorStatus() {
        TextView state = findViewById(R.id.tv_indicator_state);
        String enabled = WeatherPrefs.isTemperatureBadgeEnabled(this) ? "on" : "off";
        state.setText("Status bar weather icon: " + enabled + (WeatherStatusManager.canNotify(this)
                ? " · notifications allowed" : " · notification permission needed"));
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        } else if (!WeatherStatusManager.canNotify(this)) {
            tvStatus.setText("Notifications are blocked in Android settings. Allow them for Overcast Mini.");
        } else {
            WeatherStatusManager.sync(this);
            updateIndicatorStatus();
            tvStatus.setText("Ready! The Weather tile controls whether temperature is shown.");
        }
    }

    private void addQuickSettingsTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            StatusBarManager bar = getSystemService(StatusBarManager.class);
            if (bar != null) {
                try {
                    bar.requestAddTileService(
                            new ComponentName(this, WeatherTileService.class), "Weather",
                            Icon.createWithResource(this, R.drawable.ic_w_partly_day),
                            getMainExecutor(), code -> runOnUiThread(() ->
                                    tvStatus.setText(code == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED
                                            ? "Weather tile added. Swipe down and tap it to show the weather icon."
                                            : (code == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED
                                                ? "Weather tile is already in Quick Settings."
                                                : "Open Quick Settings → Edit and manually add the Weather tile."))));
                    return;
                } catch (RuntimeException ignored) {
                    // Some OEMs may not support the add-tile prompt.
                }
            }
        }
        tvStatus.setText("Swipe down twice → Edit tiles → add the Overcast Mini Weather tile.");
    }

    private void saveAndFinish() {
        String query = etCity.getText().toString().trim();
        if (query.isEmpty()) {
            tvStatus.setText("Enter a city name (e.g. Sonipat, London, Tokyo)");
            return;
        }
        if ("My Location".equals(query) && WeatherPrefs.hasLocation(this)) {
            applySettingsAndFetch();
            return;
        }
        btnSave.setEnabled(false);
        tvStatus.setText("Looking up city via Open-Meteo…");
        new Thread(() -> {
            OpenMeteoClient.GeoResult geo = OpenMeteoClient.searchCity(query);
            runOnUiThread(() -> {
                btnSave.setEnabled(true);
                if (geo == null) {
                    tvStatus.setText("City not found. Check spelling or network.");
                    return;
                }
                WeatherPrefs.saveLocation(this, geo.label, geo.lat, geo.lon);
                applySettingsAndFetch();
            });
        }).start();
    }

    private void applySettingsAndFetch() {
        int iv = 120;
        int checked = rgInterval.getCheckedRadioButtonId();
        if (checked == R.id.rb_1h) iv = 60;
        else if (checked == R.id.rb_2h) iv = 120;
        else if (checked == R.id.rb_3h) iv = 180;
        else if (checked == R.id.rb_6h) iv = 360;

        WeatherPrefs.saveSettings(this, swFahrenheit.isChecked(), iv);
        WeatherJobService.schedulePeriodic(this);
        WeatherJobService.triggerNow(this, true);
        WidgetRenderer.updateAll(this);
        WeatherStatusManager.sync(this);
        WeatherTileService.requestRefresh(this);

        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            Intent res = new Intent();
            res.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
            setResult(RESULT_OK, res);
        }
        finish();
    }
}
