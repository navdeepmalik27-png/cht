package com.overcast.mini;

/** Standalone US AQI widget, sharing the low-power weather refresh service. */
public final class OvercastAqiWidgetProvider extends OvercastWidgetProvider { }
