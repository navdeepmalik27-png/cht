package com.overcast.mini;

import android.appwidget.AppWidgetManager;
import android.content.Context;

/** 30-minute local astronomical redraw; does NOT initiate a weather network fetch. */
public final class OvercastSkyWidgetProvider extends OvercastWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        WidgetRenderer.updateSky(context);
        WeatherJobService.schedulePeriodic(context);
        if (WeatherPrefs.getLastUpdatedMs(context) == 0) {
            WeatherJobService.triggerNow(context, false);
        }
    }
}
