package com.overcast.mini;

/**
 * Lightweight, approximate Sun and Moon ephemeris. No external libraries or network requests.
 * Returns topocentric-looking altitude/azimuth (without parallax/refraction correction).
 * Moon accuracy is a few degrees; NOT intended for navigation or observing predictions.
 */
public final class SkyMath {
    private static final double R = Math.PI / 180.0;
    private SkyMath() {}

    public static final class Position {
        public final double altitude;
        public final double azimuth;
        Position(double altitude, double azimuth) {
            this.altitude = altitude;
            this.azimuth = azimuth;
        }
        public String compass() {
            String[] dirs = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
            return dirs[((int) Math.round(azimuth / 45.0)) % 8];
        }
    }

    public static final class Sky {
        public final Position sun;
        public final Position moon;
        public final String moonPhase;
        public final int moonIllumination;
        Sky(Position sun, Position moon, String moonPhase, int moonIllumination) {
            this.sun = sun;
            this.moon = moon;
            this.moonPhase = moonPhase;
            this.moonIllumination = moonIllumination;
        }
    }

    private static double wrap(double angle) {
        double result = angle % 360.0;
        return result < 0 ? result + 360.0 : result;
    }

    private static double sin(double degrees) { return Math.sin(degrees * R); }
    private static double cos(double degrees) { return Math.cos(degrees * R); }
    private static double atan2deg(double y, double x) { return Math.atan2(y, x) / R; }

    public static Sky calculate(double lat, double lon, long epochMillis) {
        double jd = epochMillis / 86_400_000.0 + 2_440_587.5;
        double d = jd - 2_451_545.0;
        double obliquity = 23.439291 - 0.00000036 * d;

        // Solar apparent ecliptic longitude: low-order mean anomaly approximation.
        double meanLong = wrap(280.460 + 0.9856474 * d);
        double g = wrap(357.528 + 0.9856003 * d);
        double sunLon = wrap(meanLong + 1.915 * sin(g) + 0.020 * sin(2 * g));
        Position sun = fromEcliptic(sunLon, 0, obliquity, jd, lat, lon);

        // Lunar osculating elements, approximate low-order geocentric ephemeris.
        // Epoch here is 2000 January 0.0 UTC rather than J2000 noon.
        double dm = jd - 2_451_543.5;
        double N = wrap(125.1228 - 0.0529538083 * dm);
        double inclination = 5.1454;
        double w = wrap(318.0634 + 0.1643573223 * dm);
        double eccentricity = 0.054900;
        double anomaly = wrap(115.3654 + 13.0649929509 * dm);
        double E = anomaly + eccentricity / R * sin(anomaly) * (1 + eccentricity * cos(anomaly));
        double xv = cos(E) - eccentricity;
        double yv = Math.sqrt(1 - eccentricity * eccentricity) * sin(E);
        double v = atan2deg(yv, xv);
        double r = Math.sqrt(xv * xv + yv * yv);
        double x = r * (cos(N) * cos(v + w) - sin(N) * sin(v + w) * cos(inclination));
        double y = r * (sin(N) * cos(v + w) + cos(N) * sin(v + w) * cos(inclination));
        double z = r * sin(v + w) * sin(inclination);
        double moonLon = wrap(atan2deg(y, x));
        double moonLat = atan2deg(z, Math.hypot(x, y));
        Position moon = fromEcliptic(moonLon, moonLat, obliquity, jd, lat, lon);

        double elongation = wrap(moonLon - sunLon);
        int illuminated = (int) Math.round(50.0 * (1.0 - cos(elongation)));
        String[] phases = {
                "New moon", "Waxing crescent", "First quarter", "Waxing gibbous",
                "Full moon", "Waning gibbous", "Last quarter", "Waning crescent"
        };
        int phaseIndex = ((int) Math.floor((elongation + 22.5) / 45.0)) % phases.length;
        return new Sky(sun, moon, phases[phaseIndex], illuminated);
    }

    private static Position fromEcliptic(double longitude, double latitude, double eps,
                                         double jd, double observerLat, double observerLon) {
        double ex = cos(longitude) * cos(latitude);
        double ey = sin(longitude) * cos(latitude) * cos(eps) - sin(latitude) * sin(eps);
        double ez = sin(longitude) * cos(latitude) * sin(eps) + sin(latitude) * cos(eps);
        double rightAscension = wrap(atan2deg(ey, ex));
        double declination = atan2deg(ez, Math.hypot(ex, ey));
        double t = (jd - 2_451_545.0) / 36_525.0;
        double gmst = 280.46061837 + 360.98564736629 * (jd - 2_451_545.0)
                + 0.000387933 * t * t - t * t * t / 38_710_000.0;
        double hourAngle = wrap(gmst + observerLon - rightAscension);
        double altitude = Math.asin(sin(observerLat) * sin(declination)
                + cos(observerLat) * cos(declination) * cos(hourAngle)) / R;
        double azimuth = wrap(atan2deg(-sin(hourAngle),
                Math.tan(declination * R) * cos(observerLat)
                        - sin(observerLat) * cos(hourAngle)));
        return new Position(altitude, azimuth);
    }
}
