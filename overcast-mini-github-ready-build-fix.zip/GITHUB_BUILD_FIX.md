# Fix for `bash: : No such file or directory` (exit code 127)

The old GitHub Actions workflow searched for `build_min_apk.sh` with `find -maxdepth 3`, then tried to run `bash "$SCRIPT"` even if no file was found. If no script is present in the checked-out repository, `$SCRIPT` is empty and Bash prints this error.

The replacement workflow checks the repository root, `overcast-mini-widget/`, then searches more deeply. It stops with a clear error if you uploaded only the `.github/workflows/` folder.

## Upload all files, not just the workflow

Extract the ZIP. The extracted **root** should contain these files and directories:

```
.github/workflows/build-apk.yml
app/src/main/AndroidManifest.xml
app/src/main/java/com/overcast/mini/...
app/src/main/res/...
build_min_apk.sh
README.md
```

Commit the entire extracted directory contents at the **root of your repository**, retaining the hidden `.github` directory. GitHub does not extract a ZIP you upload as a file to a repository.

Under GitHub > Actions > Build Overcast Mini APK > Run workflow, the build should locate the script. After a successful build, download the `overcast-mini-widget-apk` artifact.

Note: This repair addresses script discovery. The Android SDK APK build and Android device behavior have not been verified here.
