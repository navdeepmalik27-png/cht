# Overcast Mini v1.5 verification

## Confirmed offline checks
- Synthetic RSS Java unit test compiled and executed with Java 11 using Android/XML adapter stubs. Verified that direct `<item><title>` wins over nested `<media:title>`, suspicious IDs are excluded, 30-day-old articles are excluded, and invalid publisher domains are rejected.
- All XML resources and Android manifest pass XML parsing.
- Source and workflow ZIP files inspected.

## Limitations
- No full Android SDK or emulator build was performed in this environment.
- Indian Express section RSS URLs appear on the official publisher RSS directory, but automated direct fetching here returned access errors; phone-side live RSS availability is not verified.
- Reader/UX and background updates require live Android device verification.
- Keep the same signing keystore for upgrades: uninstalling or clearing app data deletes local bookmarks.
