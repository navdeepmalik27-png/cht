# Overcast Mini v1.4 | News categories and article reading

## The six categories

The Hindu: **Science**, **World / International**, **Top Stories** (website home feed, not printed Page One).

The Indian Express: **Explained**, **Banking & Finance**, **Economy & Policy** (official Economy RSS, not an independently verified Policy feed).

Open Overcast Mini and scroll to **News · Choose your sections**. Check or uncheck any of the six boxes. Press **Save & Update**. If all are unchecked, scheduled RSS updates pause; weather remains active. New installs default to all six checked. Existing v1.3 users keep their selected The Hindu categories and receive the three new Indian Express categories enabled for discovery unless they had explicitly turned news off.

## How to read the original article

**From the weather/news widget:** Tap the currently rotating headline to open the real publisher page in your default browser. Or tap **READ NEWS ↗** in the news panel to browse a list.

**From the app:** Choose **Browse headlines · Read full articles ↗**. Scroll the cached headline list, labelled with source and section, then select a headline or tap **Read full article ↗**. The screen has a **Refresh headlines** button and works even if you haven't placed the widget on your home screen. Browser Back returns to the app or home screen, depending on how the reader was opened.

Some publisher articles require a subscription; the app does not bypass it. Feeds and the cache only contain the title, original link, category and publish time. Network errors preserve previously cached items.

## The feeds and restrictions

The Indian Express feeds were checked against its official directory: https://indianexpress.com/rss/. That directory explicitly limits RSS consumption to personal and non-commercial use. Confirm publisher terms and permissions before public distribution; source attribution alone is not permission to syndicate content.

Background RSS refresh runs approximately every 30 minutes when a news widget is installed, as Android allows. Weather polling is separate. Only publisher HTTPS URLs are accepted as story links.

## GitHub build

Upload `overcast-mini-news-v15.zip` to the root of your GitHub repository, replace `.github/workflows/build.yml` with the supplied `build-news-v14.yml` file's contents, commit and run **Build Overcast Mini APK**. Download the `overcast-mini-news-v15-apk` artifact.

Use the *same signing keystore* to update an existing installed APK without uninstalling it; the default build generates a different signing key on each clean runner. The source package has been statically checked, but a full Android SDK build and device test are still required.

## v1.5 news reader
Open READ NEWS to switch between Latest and Saved. The ☆ Save button stores a local link/title record, and ★ Saved removes it. These bookmarks are retained across news refreshes and category changes.
