# Overcast Mini v1.8 · Neutral Frost

The glass background is neutral grayscale (R=G=B) with a genuinely transparent alpha channel. The phone wallpaper supplies the apparent beige, green, or other hue behind it. No blue or beige tint is baked into these backgrounds. Neutral smoke opacity ~35–45% keeps white text legible, while wallpaper remains visible. The panel is not a live backdrop blur and cannot refract the wallpaper (standard Android RemoteViews limitation).

All six widgets use these backgrounds in glass mode. The 15 scene names include barely visible monochrome precipitation/fog/starlight texture, away from the top-right temperature zone. No large sun, moon, or circle is drawn in background assets. The news widget's real weather icon is a single foreground ImageView immediately to the left of the temperature, with no badge. Glass inner panels and pills use subtle neutral fills and 0.5dp low-opacity strokes. News headlines, rotation, and bookmarks are unchanged.

A GitHub Actions workflow is included. A successful on-device visual check on OxygenOS is still necessary to verify alignment and legibility with an actual wallpaper.
