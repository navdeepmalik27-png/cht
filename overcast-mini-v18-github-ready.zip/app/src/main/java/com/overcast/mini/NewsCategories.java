package com.overcast.mini;

import android.content.Context;
import android.content.SharedPreferences;

/** Individually selected, read-only publisher RSS sections. */
public final class NewsCategories {
    public static final int SCIENCE = 1;
    public static final int WORLD = 2;
    public static final int TOP_STORIES = 4;
    public static final int EXPLAINED = 8;
    public static final int BANKING_FINANCE = 16;
    public static final int ECONOMY_POLICY = 32;
    public static final int HINDU_ALL = SCIENCE | WORLD | TOP_STORIES;
    public static final int EXPRESS_ALL = EXPLAINED | BANKING_FINANCE | ECONOMY_POLICY;
    public static final int ALL = HINDU_ALL | EXPRESS_ALL;
    private static final String PREFS = "overcast_headlines";
    private static final String SELECTED_V3 = "selected_sections_v3";
    private static final String SELECTED_V2 = "selected_sections_v2";

    private NewsCategories() { }

    public static int selected(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (prefs.contains(SELECTED_V3)) return prefs.getInt(SELECTED_V3, ALL) & ALL;
        if (prefs.contains(SELECTED_V2)) {
            int previous = prefs.getInt(SELECTED_V2, HINDU_ALL) & HINDU_ALL;
            // Preserve deliberate "all off" choices. Otherwise include the new sections
            // on first upgrade so users can discover them and deselect any they don't want.
            int upgraded = previous == 0 ? 0 : previous | EXPRESS_ALL;
            prefs.edit().putInt(SELECTED_V3, upgraded).apply();
            return upgraded;
        }
        return ALL;
    }

    public static boolean save(Context context, int selection) {
        selection &= ALL;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (selected(context) == selection) return false;
        prefs.edit().putInt(SELECTED_V3, selection).apply();
        return true;
    }

    public static String label(int category) {
        switch (category) {
            case SCIENCE: return "Science";
            case WORLD: return "World";
            case TOP_STORIES: return "Top Stories";
            case EXPLAINED: return "Explained";
            case BANKING_FINANCE: return "Banking & Finance";
            case ECONOMY_POLICY: return "Economy & Policy";
            default: return "News";
        }
    }

    public static String publisher(int category) {
        return (category & EXPRESS_ALL) != 0 ? "The Indian Express" : "The Hindu";
    }

    public static String attribution(int category) {
        return publisher(category) + " · " + label(category);
    }
}
