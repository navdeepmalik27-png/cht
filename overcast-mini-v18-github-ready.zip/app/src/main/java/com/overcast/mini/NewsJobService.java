package com.overcast.mini;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.util.Log;

/** Independent, opt-in RSS polling; never starts unless a news widget exists. */
public final class NewsJobService extends JobService {
    private static final int JOB_PERIODIC = 211;
    private static final int JOB_NOW = 212;
    private static final long PERIOD_MS = 30 * 60_000L;
    private volatile boolean stopped;

    public static boolean hasNewsWidgets(Context context) {
        return AppWidgetManager.getInstance(context).getAppWidgetIds(
                new ComponentName(context, OvercastNewsWidgetProvider.class)).length > 0;
    }

    public static void schedule(Context context) {
        if (!hasNewsWidgets(context) || NewsCategories.selected(context) == 0) {
            cancelWhenUnused(context);
            return;
        }
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null) return;
        JobInfo existing = scheduler.getPendingJob(JOB_PERIODIC);
        if (existing != null && existing.getIntervalMillis() == PERIOD_MS) return;
        JobInfo job = new JobInfo.Builder(JOB_PERIODIC,
                new ComponentName(context, NewsJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setRequiresBatteryNotLow(true)
                .setPeriodic(PERIOD_MS, 10 * 60_000L)
                .setPersisted(true)
                .build();
        scheduler.schedule(job);
    }

    public static void refresh(Context context, boolean force) {
        if (!hasNewsWidgets(context) || NewsCategories.selected(context) == 0) return;
        if (!force && System.currentTimeMillis() - NewsStore.updatedAt(context) < 5 * 60_000L) {
            WidgetRenderer.updateNews(context);
            return;
        }
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler != null) {
            JobInfo job = new JobInfo.Builder(JOB_NOW,
                    new ComponentName(context, NewsJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setOverrideDeadline(10_000L).build();
            scheduler.schedule(job);
        }
    }

    public static void cancelWhenUnused(Context context) {
        if (hasNewsWidgets(context) && NewsCategories.selected(context) != 0) return;
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler != null) {
            scheduler.cancel(JOB_PERIODIC);
            scheduler.cancel(JOB_NOW);
        }
    }

    @Override public boolean onStartJob(JobParameters params) {
        if (!hasNewsWidgets(this) || NewsCategories.selected(this) == 0) return false;
        stopped = false;
        final int selection = NewsCategories.selected(this);
        new Thread(() -> {
            try {
                java.util.ArrayList<NewsFeedClient.Headline> latest =
                        NewsFeedClient.fetchSelected(selection);
                // Avoid replacing the cache with results for categories since deselected.
                if (!stopped && hasNewsWidgets(this)
                        && selection == NewsCategories.selected(this)) NewsStore.save(this, latest);
            } catch (Exception error) {
                Log.w("OvercastRSS", "Could not update selected RSS feeds; using last cached headlines", error);
            } finally {
                if (!stopped) WidgetRenderer.updateNews(this);
                jobFinished(params, false);
            }
        }, "Overcast-RSS").start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) {
        stopped = true;
        return false;
    }
}
