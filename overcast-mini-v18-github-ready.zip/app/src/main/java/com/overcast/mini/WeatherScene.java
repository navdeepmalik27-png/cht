package com.overcast.mini;

import android.content.Context;
import android.widget.RemoteViews;

/** Selects pre-rendered, translucent weather art for optional widget glass mode.
 *  Only cached Open-Meteo WMO code/is_day is used. No extra wakeups or network calls.
 */
public final class WeatherScene {
    private WeatherScene() { }

    public static int glassLayout(int normalLayout) {
        if (normalLayout == R.layout.widget_overcast_compact) return R.layout.widget_overcast_compact_glass;
        if (normalLayout == R.layout.widget_overcast_forecast) return R.layout.widget_overcast_forecast_glass;
        if (normalLayout == R.layout.widget_overcast_aqi) return R.layout.widget_overcast_aqi_glass;
        if (normalLayout == R.layout.widget_overcast_precip) return R.layout.widget_overcast_precip_glass;
        if (normalLayout == R.layout.widget_overcast_sky) return R.layout.widget_overcast_sky_glass;
        if (normalLayout == R.layout.widget_overcast_news) return R.layout.widget_overcast_news_glass;
        return normalLayout;
    }

    /** Unknown or old forecasts get neutral frost instead of claiming current skies. */
    public static int artFor(WeatherData data, long ageMs) {
        if (data == null || ageMs < 0 || ageMs > 6L * 60 * 60 * 1000)
            return R.drawable.glass_neutral;
        int wmo = data.wmoCode;
        boolean day = data.isDay;
        if (wmo >= 95 && wmo <= 99) return day ? R.drawable.glass_storm_day : R.drawable.glass_storm_night;
        if (wmo >= 71 && wmo <= 77 || wmo == 85 || wmo == 86)
            return day ? R.drawable.glass_snow_day : R.drawable.glass_snow_night;
        if (wmo >= 51 && wmo <= 67 || wmo >= 80 && wmo <= 82)
            return day ? R.drawable.glass_rain_day : R.drawable.glass_rain_night;
        if (wmo == 45 || wmo == 48) return day ? R.drawable.glass_fog_day : R.drawable.glass_fog_night;
        if (wmo == 3) return day ? R.drawable.glass_cloudy_day : R.drawable.glass_cloudy_night;
        if (wmo == 1 || wmo == 2)
            return day ? R.drawable.glass_partly_day : R.drawable.glass_partly_night;
        return day ? R.drawable.glass_clear_day : R.drawable.glass_clear_night;
    }

    public static void apply(Context context, RemoteViews rv) {
        WeatherData data = WeatherData.parse(WeatherPrefs.getCachedJson(context));
        long last = WeatherPrefs.getLastUpdatedMs(context);
        long age = last == 0 ? -1 : System.currentTimeMillis() - last;
        rv.setImageViewResource(R.id.glass_scene, artFor(data, age));
    }
}
