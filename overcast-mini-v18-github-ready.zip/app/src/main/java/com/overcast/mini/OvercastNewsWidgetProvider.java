package com.overcast.mini;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;

/** Optional weather + rotating selected publisher RSS headlines widget. */
public final class OvercastNewsWidgetProvider extends AppWidgetProvider {
    @Override public void onEnabled(Context context) {
        WeatherJobService.schedulePeriodic(context);
        NewsJobService.schedule(context);
    }

    @Override public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        WidgetRenderer.updateNews(context);
        NewsJobService.schedule(context);
        NewsJobService.refresh(context, false);
        WeatherJobService.schedulePeriodic(context);
        long maxAge = Math.max(15, WeatherPrefs.getIntervalMinutes(context) / 2) * 60_000L;
        if (WeatherPrefs.hasLocation(context)
                && System.currentTimeMillis() - WeatherPrefs.getLastUpdatedMs(context) > maxAge)
            WeatherJobService.triggerNow(context, false);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (WidgetRenderer.ACTION_REFRESH.equals(intent.getAction())) {
            WeatherJobService.triggerNow(context, false);
            NewsJobService.refresh(context, true);
        }
    }

    @Override public void onDisabled(Context context) {
        NewsJobService.cancelWhenUnused(context);
        WeatherJobService.cancelWhenUnused(context);
    }
}
