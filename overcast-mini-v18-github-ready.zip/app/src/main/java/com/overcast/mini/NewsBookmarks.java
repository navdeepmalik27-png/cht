package com.overcast.mini;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Private offline reading list: saved links and headlines, never article bodies. */
public final class NewsBookmarks {
    private static final String PREF = "overcast_saved_articles_v1";
    private static final String KEY = "bookmarks";
    private static final int LIMIT = 200;
    private static final Object LOCK = new Object();
    private NewsBookmarks() { }

    public static List<NewsFeedClient.Headline> read(Context context) {
        synchronized (LOCK) { return readUnlocked(context); }
    }

    private static ArrayList<NewsFeedClient.Headline> readUnlocked(Context context) {
        SharedPreferences pref = context.getApplicationContext()
                .getSharedPreferences(PREF, Context.MODE_PRIVATE);
        ArrayList<NewsFeedClient.Headline> out = new ArrayList<>();
        try {
            JSONArray entries = new JSONArray(pref.getString(KEY, "[]"));
            for (int i = 0; i < entries.length() && out.size() < LIMIT; i++) {
                JSONObject row = entries.optJSONObject(i);
                if (row == null) continue;
                String url = row.optString("url", "");
                String title = row.optString("title", "");
                int category = row.optInt("category", 0);
                if (NewsFeedClient.isPublisherLink(url) && !title.trim().isEmpty()) {
                    out.add(new NewsFeedClient.Headline(title, url,
                            row.optLong("date", 0L), category));
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    public static boolean contains(Context context, String url) {
        synchronized (LOCK) {
            for (NewsFeedClient.Headline item : readUnlocked(context)) {
                if (item.url.equals(url)) return true;
            }
            return false;
        }
    }

    /** Returns true when newly bookmarked, false when removed or invalid. */
    public static boolean toggle(Context context, NewsFeedClient.Headline headline) {
        if (headline == null || !NewsFeedClient.isPublisherLink(headline.url)) return false;
        synchronized (LOCK) {
            ArrayList<NewsFeedClient.Headline> previous = readUnlocked(context);
            ArrayList<NewsFeedClient.Headline> next = new ArrayList<>();
            boolean found = false;
            for (NewsFeedClient.Headline item : previous) {
                if (item.url.equals(headline.url)) found = true;
                else next.add(item);
            }
            if (!found) next.add(0, headline);
            if (next.size() > LIMIT) next.subList(LIMIT, next.size()).clear();
            JSONArray data = new JSONArray();
            for (NewsFeedClient.Headline item : next) {
                JSONObject row = new JSONObject();
                try {
                    row.put("title", item.title);
                    row.put("url", item.url);
                    row.put("date", item.publishedMs);
                    row.put("category", item.category);
                    data.put(row);
                } catch (Exception ignored) { }
            }
            context.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .edit().putString(KEY, data.toString()).apply();
            return !found;
        }
    }
}
