package com.overcast.mini;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/** Read-only local headline list. Full stories always open on publisher websites. */
public final class NewsBrowseActivity extends Activity {
    private LinearLayout list;
    private TextView status;
    private Button refresh;
    private Button latestTab, savedTab;
    private boolean showSaved;
    private boolean busy;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("News · Overcast Mini");
        showSaved = getIntent().getBooleanExtra("show_saved", false);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(getColor(R.color.oc_surface));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView heading = text("Headlines", 26, R.color.oc_on_surface);
        heading.setTypeface(null, Typeface.BOLD);
        root.addView(heading);
        root.addView(text("The Hindu + The Indian Express · selected sections", 12,
                R.color.oc_on_surface_variant));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(10), 0, dp(4));
        refresh = new Button(this);
        refresh.setAllCaps(false);
        refresh.setText("Refresh headlines");
        refresh.setOnClickListener(v -> refreshFeeds());
        actions.addView(refresh, new LinearLayout.LayoutParams(0, dp(52), 1f));
        Button settings = new Button(this);
        settings.setAllCaps(false);
        settings.setText("Sections");
        settings.setOnClickListener(v -> startActivity(new Intent(this, ConfigActivity.class)));
        actions.addView(settings);
        root.addView(actions);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        latestTab = new Button(this);
        latestTab.setAllCaps(false);
        latestTab.setOnClickListener(v -> { showSaved = false; displayCached(); });
        tabs.addView(latestTab, new LinearLayout.LayoutParams(0, dp(48), 1f));
        savedTab = new Button(this);
        savedTab.setAllCaps(false);
        savedTab.setOnClickListener(v -> { showSaved = true; displayCached(); });
        tabs.addView(savedTab, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(tabs);

        status = text("", 12, R.color.oc_on_surface_variant);
        status.setPadding(0, 0, 0, dp(8));
        root.addView(status);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);
        setContentView(scroll);
        displayCached();
        if (!showSaved && NewsStore.read(this).isEmpty()
                && NewsCategories.selected(this) != 0) refreshFeeds();
    }

    @Override protected void onResume() {
        super.onResume();
        if (list != null && !busy) displayCached();
    }

    private void displayCached() {
        list.removeAllViews();
        List<NewsFeedClient.Headline> savedItems = NewsBookmarks.read(this);
        java.util.Set<String> savedUrls = new java.util.HashSet<>();
        for (NewsFeedClient.Headline saved : savedItems) savedUrls.add(saved.url);
        int savedCount = savedItems.size();
        latestTab.setText(showSaved ? "Latest" : "✓ Latest");
        savedTab.setText((showSaved ? "✓ " : "") + "Saved (" + savedCount + ")");
        refresh.setVisibility(showSaved ? View.GONE : View.VISIBLE);
        List<NewsFeedClient.Headline> items;
        if (showSaved) {
            items = savedItems;
            status.setText(items.isEmpty()
                    ? "No bookmarks yet. Open Latest and tap ☆ Save on an article."
                    : items.size() + " saved articles · stored on this device");
        } else {
            if (NewsCategories.selected(this) == 0) {
                status.setText("All categories are off. Open Sections or view Saved articles.");
                return;
            }
            items = NewsStore.read(this);
            if (items.isEmpty()) {
                status.setText("No recent headlines. Refresh, or check your selected sections.");
                return;
            }
            status.setText(items.size() + " recent headlines · updated "
                    + NewsStore.ageLabel(NewsStore.updatedAt(this), System.currentTimeMillis())
                    + " · select ☆ Save to bookmark");
        }
        for (NewsFeedClient.Headline h : items) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            GradientDrawable shape = new GradientDrawable();
            shape.setColor(getColor(R.color.oc_surface_container));
            shape.setCornerRadius(dp(18));
            card.setBackground(shape);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            cp.bottomMargin = dp(9);
            list.addView(card, cp);

            TextView byline = text(NewsCategories.attribution(h.category) + " · "
                    + NewsStore.ageLabel(h.publishedMs, System.currentTimeMillis()),
                    11, R.color.oc_on_surface_variant);
            card.addView(byline);
            TextView headline = text(h.title, 16, R.color.oc_on_surface);
            headline.setTypeface(null, Typeface.BOLD);
            headline.setPadding(0, dp(6), 0, dp(6));
            card.addView(headline);
            headline.setOnClickListener(v -> openArticle(h.url));

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            Button read = new Button(this);
            read.setAllCaps(false);
            read.setText("Read article ↗");
            read.setOnClickListener(v -> openArticle(h.url));
            actions.addView(read, new LinearLayout.LayoutParams(0, dp(48), 1f));
            Button bookmark = new Button(this);
            bookmark.setAllCaps(false);
            bookmark.setText(savedUrls.contains(h.url) ? "★ Saved" : "☆ Save");
            bookmark.setContentDescription("Bookmark article: " + h.title);
            bookmark.setOnClickListener(v -> {
                boolean nowSaved = NewsBookmarks.toggle(this, h);
                if (showSaved) displayCached();
                else {
                    bookmark.setText(nowSaved ? "★ Saved" : "☆ Save");
                    savedTab.setText("Saved (" + NewsBookmarks.read(this).size() + ")");
                }
            });
            actions.addView(bookmark, new LinearLayout.LayoutParams(0, dp(48), 1f));
            card.addView(actions);
        }
    }

    private void openArticle(String url) {
        if (!NewsFeedClient.isPublisherLink(url)) return;
        Intent open = new Intent(this, NewsLinkActivity.class);
        open.putExtra(NewsLinkActivity.EXTRA_URL, url);
        startActivity(open);
    }

    private void refreshFeeds() {
        if (busy) return;
        int chosen = NewsCategories.selected(this);
        if (chosen == 0) {
            status.setText("Select at least one news category in Sections.");
            return;
        }
        busy = true;
        refresh.setEnabled(false);
        status.setText("Fetching selected publisher headlines…");
        new Thread(() -> {
            String failure = null;
            try {
                ArrayList<NewsFeedClient.Headline> items = NewsFeedClient.fetchSelected(chosen);
                if (chosen == NewsCategories.selected(this)) {
                    NewsStore.save(this, items);
                    WidgetRenderer.updateNews(this);
                }
            } catch (Exception e) {
                failure = "Couldn't refresh RSS. Showing saved headlines if available.";
            }
            final String result = failure;
            runOnUiThread(() -> {
                busy = false;
                refresh.setEnabled(true);
                displayCached();
                if (result != null) status.setText(result);
            });
        }, "Overcast-News-Browse").start();
    }

    private TextView text(String value, int sp, int color) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextColor(getColor(color));
        tv.setTextSize(sp);
        return tv;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
