package com.overcast.mini;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Store no article bodies: only attributed headlines, HTTPS links, and dates. */
public final class NewsStore {
    private static final String PREF = "overcast_headlines";
    private NewsStore() {}

    public static void save(Context context, List<NewsFeedClient.Headline> headlines) {
        JSONArray rows = new JSONArray();
        for (NewsFeedClient.Headline h : headlines) {
            if (!NewsFeedClient.isPublisherLink(h.url)) continue;
            JSONObject row = new JSONObject();
            try {
                row.put("title", h.title);
                row.put("url", h.url);
                row.put("date", h.publishedMs);
                row.put("category", h.category);
                rows.put(row);
            } catch (Exception ignored) { }
            if (rows.length() >= NewsFeedClient.MAX_ITEMS) break;
        }
        if (rows.length() == 0) return; // preserve last good cache on a failed/empty feed
        context.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putString("items", rows.toString())
                .putLong("updated", System.currentTimeMillis()).apply();
    }

    public static List<NewsFeedClient.Headline> read(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF, Context.MODE_PRIVATE);
        ArrayList<NewsFeedClient.Headline> out = new ArrayList<>();
        try {
            JSONArray rows = new JSONArray(prefs.getString("items", "[]"));
            for (int i = 0; i < rows.length() && out.size() < NewsFeedClient.MAX_ITEMS; i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null) continue;
                String url = row.optString("url", "");
                String title = row.optString("title", "");
                int category = row.optInt("category", 0);
                // Old v1.2 India/National caches have no category: do not mislabel them.
                long publishedMs = row.optLong("date", 0L);
                if ((NewsCategories.selected(context) & category) != 0
                        && NewsFeedClient.isPublisherLink(url)
                        && NewsFeedClient.isPlausibleHeadline(title)
                        && NewsFeedClient.isRecent(publishedMs, System.currentTimeMillis()))
                    out.add(new NewsFeedClient.Headline(title, url, publishedMs, category));
            }
        } catch (Exception ignored) { }
        return out;
    }

    public static long updatedAt(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getLong("updated", 0L);
    }

    public static String ageLabel(long timestamp, long now) {
        if (timestamp <= 0 || timestamp > now + 120000L) return "Latest";
        long mins = Math.max(0L, (now - timestamp) / 60000L);
        if (mins < 1) return "Just now";
        if (mins < 60) return mins + "m ago";
        long hrs = mins / 60L;
        if (hrs < 24) return hrs + "h ago";
        return (hrs / 24L) + "d ago";
    }
}
