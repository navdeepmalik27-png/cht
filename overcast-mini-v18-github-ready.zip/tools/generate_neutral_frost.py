"""Generate transparent, neutral RGBA weather-ambient widget assets.
No embedded sun/moon icons, tinted backgrounds, or pronounced outer borders.
The Android launcher shows wallpaper through the assets' alpha channel.
"""
from PIL import Image, ImageDraw, ImageFilter
import numpy as np
from pathlib import Path
import math

W, H = 640, 360
base = Path(__file__).resolve().parent.parent / 'app/src/main/res'
patterns = ['neutral', 'clear_day', 'clear_night', 'partly_day', 'partly_night',
            'cloudy_day', 'cloudy_night', 'fog_day', 'fog_night',
            'rain_day', 'rain_night', 'snow_day', 'snow_night', 'storm_day', 'storm_night']
seed = np.random.default_rng(1708)
y, x = np.mgrid[0:H, 0:W]
# Anti-aliased rounded mask leaves the launcher wallpaper visible outside the card.
mask = Image.new('L', (W * 2, H * 2))
md = ImageDraw.Draw(mask)
md.rounded_rectangle((1,1,W*2-2,H*2-2), radius=100, fill=255)
mask = mask.resize((W,H), Image.Resampling.LANCZOS)
mask_arr = np.asarray(mask, dtype=np.float32) / 255.0

for folder in ['drawable-nodpi','drawable-night-nodpi']:
    outdir = base / folder
    dark = folder.startswith('drawable-night')
    for name in patterns:
        # Subtle neutral smoke; RGB remains grayscale rather than blue/beige.
        # Alpha is deliberately low enough for real wallpaper color to show through.
        vignette = 3.0 * ((x/W - .5)**2 + (y/H-.45)**2)
        alpha = (91 if not dark else 101) + 9*(1-y/H) + vignette
        sheen = np.exp(-((x / W - 0.18)**2 / .11 + (y/H-.04)**2/.045))
        alpha -= 5 * sheen
        gentle_grain = seed.normal(0, 0.75, (H,W))
        alpha += gentle_grain
        gray = 45 if not dark else 34
        rgb = np.full((H,W), gray, dtype=np.float32)
        # Soft light sweep at top left; zero hues, no stylized sky-color panel.
        rgb += 11*sheen
        if 'fog_' in name:
            # Neutral, milky haze, extremely low-frequency tonal shift.
            rgb += 8 * np.exp(-((y/H - .65)**2)/.16)
            alpha += 2
        if name.endswith('night'):
            alpha += 7
        if 'storm_' in name:
            alpha += 5
        # No decorative star/dot near the temperature; ambience is restricted to the left.
        arr = np.zeros((H,W,4), dtype=np.uint8)
        for i in range(3): arr[:,:,i] = np.clip(rgb,0,255).astype('uint8')
        arr[:,:,3] = np.clip(alpha * mask_arr,0,255).astype('uint8')
        im = Image.fromarray(arr, 'RGBA')
        # Minimal ambient motifs. All shapes are monochrome and barely visible.
        overlay = Image.new('RGBA', (W,H), (0,0,0,0))
        od = ImageDraw.Draw(overlay)
        if 'rain_' in name or 'storm_' in name:
            for k in range(12):
                px=26+k*24
                py=145+(k*29)%135
                od.line((px,py,px-7,py+17), fill=(238,238,238,8), width=1)
        if 'snow_' in name or 'clear_night' in name:
            for k in range(13):
                px=30+(k*59)%290
                py=60+(k*43)%245
                rad=1 if k%3 else 2
                od.ellipse((px-rad,py-rad,px+rad,py+rad), fill=(242,242,242,12))
        if 'cloudy_' in name or 'partly_' in name or 'fog_' in name:
            for k in range(3):
                py=225 + k*20
                od.arc((18,py,300,py+70), 190,325, fill=(242,242,242,8),width=2)
        overlay.putalpha(Image.fromarray((np.asarray(overlay.getchannel('A'),dtype=np.float32)*mask_arr).astype('uint8')))
        im=Image.alpha_composite(im, overlay)
        # Optical edge highlight: barely perceptible, NOT a full outlined stroke.
        outline=Image.new('RGBA',(W,H),(0,0,0,0))
        draw=ImageDraw.Draw(outline)
        draw.arc((2,2,W-3,H-3), 190,355, fill=(255,255,255,15), width=1)
        im=Image.alpha_composite(im,outline)
        im.save(outdir / f'glass_{name}.png', optimize=True)
        print(f'{folder}/glass_{name}.png', round(float(np.asarray(im.getchannel('A')).mean())))
