#!/usr/bin/env python3
"""Pre-render subtle weather-reactive smoked-glass backdrops for Android RemoteViews.
This is a development-only asset generator. Runtime does not require Pillow/numpy.
No literal sun/moon weather glyphs are drawn in the weather/temperature header area:
foreground R.id.*_weather_icon is the ONLY visible weather icon.
"""
from pathlib import Path
import math
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

DEST = Path(__file__).resolve().parent.parent / 'app/src/main/res/drawable-nodpi'
DEST.mkdir(parents=True, exist_ok=True)
W, H = 640, 360
Y, X = np.mgrid[0:H,0:W].astype(np.float32)


def ellipse_glow(im, center, scale, color, strength, blur=0):
    ox,oy=center; sx,sy=scale
    fall=np.exp(-(((X-ox)/sx)**2+((Y-oy)/sy)**2)*1.8)
    rgba=np.zeros((H,W,4), dtype=np.uint8)
    rgba[:,:,:3]=color
    rgba[:,:,3]=np.clip(fall*strength,0,255).astype(np.uint8)
    layer=Image.fromarray(rgba,'RGBA')
    if blur: layer=layer.filter(ImageFilter.GaussianBlur(blur))
    return Image.alpha_composite(im,layer)


def make(kind, period):
    night=period=='night'
    seed=1000 + sum(map(ord,kind+period))
    rng=np.random.default_rng(seed)
    # Dark mineral glass provides contrast independent of Android's global dark-mode.
    # Opacity below 255 allows the actual launcher wallpaper to show softly through.
    top=(22,34,54) if night else (43,56,71)
    bottom=(17,28,47) if night else (38,52,67)
    t=np.clip(.54*(Y/H)+.18*(X/W),0,1)
    color=np.stack([top[i]*(1-t)+bottom[i]*t for i in range(3)],axis=-1)
    # Frost: multi-scale correlated noise, avoiding synthetic solid-color slabs.
    coarse=Image.fromarray(rng.integers(0,255,(24,44),dtype=np.uint8),'L').resize((W,H),Image.Resampling.BICUBIC).filter(ImageFilter.GaussianBlur(16))
    coarse=(np.asarray(coarse).astype(np.float32)-127.)*0.12
    grain=rng.normal(0,0.9,size=(H,W)).astype(np.float32)
    color=np.clip(color + coarse[...,None] + grain[...,None],0,255).astype(np.uint8)
    # 0.80 opacity for legibility; outer corners are fully transparent.
    arr=np.concatenate([color,np.full((H,W,1),202,dtype=np.uint8)],axis=2)
    im=Image.fromarray(arr,'RGBA')
    # Atmospheric optical diffusion and a hint of colored reflected light.
    warmth=(243,193,123)
    cool=(133,196,227)
    if kind in ('clear','partly') and not night:
        im=ellipse_glow(im,(100,260),(260,245),warmth,42)
    elif kind in ('clear','partly') and night:
        im=ellipse_glow(im,(75,290),(260,220),(123,163,225),31)
    elif kind=='fog':
        im=ellipse_glow(im,(190,275),(450,145),(198,221,228),54)
    elif kind=='snow':
        im=ellipse_glow(im,(120,280),(350,190),(171,207,237),53)
    elif kind=='rain':
        im=ellipse_glow(im,(100,285),(360,230),(81,162,206),28)
    elif kind=='storm':
        im=ellipse_glow(im,(85,290),(310,250),(100,125,183),35)
    else:
        im=ellipse_glow(im,(120,315),(390,190),(161,194,206),34)
    # Broad white frost haze from the left/lower area: NEVER put a bright object
    # behind the right-side foreground temperature/weather glyph.
    im=ellipse_glow(im,(-110,240),(370,440),(237,249,255),27)
    im=ellipse_glow(im,(345,420),(320,225),(192,218,239),26)

    # Soft blurred cloud banks and winter mist with NO recognizable sun/moon disc.
    if kind in ('cloudy','partly','fog','rain','snow','storm'):
        layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer)
        strength=22 if kind!='fog' else 44
        cloud_color=(213,232,242,strength)
        for x,y,rw,rh in [(-80,254,230,96),(90,300,260,110),(320,276,250,90),(480,337,260,74)]:
            d.ellipse((x-rw/2,y-rh/2,x+rw/2,y+rh/2),fill=cloud_color)
        im=Image.alpha_composite(im,layer.filter(ImageFilter.GaussianBlur(23)))
    if kind=='fog':
        layer=Image.new('RGBA',(W,H)); d=ImageDraw.Draw(layer)
        for y in (206,252,312):
            d.rounded_rectangle((22,y,574,y+15),radius=8,fill=(222,237,242,29))
        im=Image.alpha_composite(im,layer.filter(ImageFilter.GaussianBlur(17)))
    if kind in ('rain','storm'):
        layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer)
        for x,y in zip(rng.integers(30,590,25),rng.integers(174,346,25)):
            d.line((int(x),int(y),int(x)-9,int(y)+22),fill=(174,217,251,28),width=2)
        im=Image.alpha_composite(im,layer.filter(ImageFilter.GaussianBlur(.7)))
    if kind=='snow':
        layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer)
        for x,y in zip(rng.integers(22,612,38),rng.integers(152,345,38)):
            r=int(rng.integers(1,3));d.ellipse((int(x)-r,int(y)-r,int(x)+r,int(y)+r),fill=(233,243,255,65))
        im=Image.alpha_composite(im,layer.filter(ImageFilter.GaussianBlur(.5)))
    # night sky uses a few pinprick stars, below weather header and with weak alpha
    # (no moon illustration: the foreground current-conditions icon remains singular).
    if night and kind in ('clear','partly','cloudy'):
        layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer)
        for x,y in zip(rng.integers(36,594,28),rng.integers(155,321,28)):
            r=1 if rng.random()<.8 else 2
            d.ellipse((int(x)-r,int(y)-r,int(x)+r,int(y)+r),fill=(231,241,255,int(rng.integers(26,65))))
        im=Image.alpha_composite(im,layer)

    # Top-left liquid glass reflections and a narrow edge shimmer.
    layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer)
    d.ellipse((-220,-315,510,215), fill=(252,255,255,14))
    layer=layer.filter(ImageFilter.GaussianBlur(33))
    im=Image.alpha_composite(im,layer)
    gloss=np.zeros((H,W,4),np.uint8)
    gloss[:,:,:3]=(242,251,255)
    gloss[:,:,3]=np.clip(20*np.exp(-(((X-24)/150)**2+((Y-115)/280)**2)),0,255).astype(np.uint8)
    im=Image.alpha_composite(im,Image.fromarray(gloss,'RGBA'))
    # Fine bright perimeter, glass-style specular highlights, bottom shadow.
    edge=Image.new('RGBA',(W,H));d=ImageDraw.Draw(edge)
    d.rounded_rectangle((1,1,W-2,H-2),radius=58,outline=(235,249,255,117),width=2)
    # No giant interior arcs: they compete with headlines on compact widgets.
    im=Image.alpha_composite(im,edge)
    mask=Image.new('L',(W,H),0);md=ImageDraw.Draw(mask)
    md.rounded_rectangle((1,1,W-2,H-2),radius=58,fill=255)
    im.putalpha(Image.fromarray(np.minimum(np.asarray(im.getchannel('A')),np.asarray(mask)).astype(np.uint8),'L'))
    return im

for kind in ('neutral','clear','partly','cloudy','fog','rain','snow','storm'):
    for period in (('day','night') if kind!='neutral' else ('',)):
        name='glass_'+kind+('_'+period if period else '')+'.png'
        im=make(kind,period or 'day')
        im.save(DEST/name,optimize=True)
        print(name, (DEST/name).stat().st_size)
