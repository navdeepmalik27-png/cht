# Overcast Mini v1.6: Frosted Glass Mode

## Where to find it
Open the Overcast Mini launcher app. Scroll to the **Frosted Glass widgets** switch below the Fahrenheit setting. Toggling it updates all installed widgets immediately without changing the selected city or fetching extra weather data. The switch is saved locally.

## What changes
- All six home widgets receive a translucent rounded sky background: Weather Compact, Forecast, AQI, Precipitation, Sun & Moon, Weather + Headlines.
- The forecast and headline inner panels use a translucent frosted layer to keep text readable.
- Backgrounds follow cached weather WMO condition and `is_day`: sun/clouds in daylight, moon/stars on clear nights, clouds, fog layers, rain, snow and thunderstorms as appropriate.
- Separate light/dark phone-theme versions keep text readable. Android's wallpaper can show faintly through the illustration.
- With missing or old weather data (>6 hours), backgrounds switch to a neutral frosted appearance rather than implying the current conditions are known.

## Battery and technical limits
Artwork is bundled as static PNG assets. No animation, extra network calls, location polling or blur processing. Android's normal home-screen widget interface does **not** provide reliable access to the live wallpaper pixels to blur; this is a frosted-glass visual effect with translucency, not a real-time wallpaper blur.

## Headline layout
Only the headline occupies the rotating item; the publisher remains at the top of the card, and the **Read News** action stays there. Section labels remain available inside the in-app reader, not in the small widget headline area.

## Building
Upload `overcast-mini-news-v16-glass.zip` to the repository root and put the companion `build-news-v16.yml` contents into `.github/workflows/build.yml`. Run the workflow; it extracts the ZIP, builds, signs (with your keystore secrets if configured) and publishes `overcast-mini-news-v16-apk`.

Your previous install must be signed with the same signing key for an in-place upgrade. Do not uninstall the old version if preserving local bookmark and app settings matters.
