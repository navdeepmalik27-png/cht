## v1.6 | Glass widgets and readable headlines
- Removed redundant headline-row publisher and section labels from the Weather + News home-screen widget.
- Expanded headline text to full width and up to 3 lines; existing header source label and Read News action remain.
- Added persistent **Frosted Glass widgets** toggle in Settings; redrawing from cached weather is immediate.
- Added glass layout variants for all six widgets and 30 pre-rendered weather backgrounds (15 conditions/time combinations, day/dark theme).
- Art uses translucent tinted gradients, frost panels, sun, moon, stars, cloud, rain, snow, fog and storms. No real wallpaper blur or continuous animation.
- Weather-driven art uses cached WMO code and day/night; neutral fallback for unavailable/stale data.
- Preserved six selectable RSS categories, article links, bookmarks and status-bar weather icons.

# Changelog

## v1.5 – Clean RSS titles and local bookmarks
- Corrected the Indian Express RSS parser so nested `media:title` content never replaces an item’s real headline, avoiding image IDs and file names in the widget.
- Added minimum headline quality checks, 5-day publication recency check, and validation of the existing cached feed on read; old malformed entries will disappear automatically. New RSS fetch is scheduled after app upgrade when a news widget exists.
- Added private, on-device bookmarks (up to 200 title/link/date/section records), independent of selected sections and feed expiry.
- Added `Latest` and `Saved` tabs in the headline reader; save/unsave from individual article cards and read original publisher articles in browser.
- Preserved all six selected RSS sections, five weather-only widgets, weather+news widget, temperature icon, and Quick Settings tile.
- Upgraded versionCode 5 / versionName 1.5; regenerated GitHub ZIP build workflow.

# Changelog

## v1.4 – Indian Express feeds and full-article reading
- Added opt-in Indian Express **Explained**, **Banking & Finance**, and **Economy & Policy** (the official Economy RSS feed), alongside The Hindu Science, World, and Top Stories. Each section can be toggled independently in app settings.
- Increased cached headlines to 24, interleaved across up to six feeds; publisher and category attribution included with every headline.
- Added a **READ NEWS** entry point on the weather/news widget and **Browse headlines** in settings. A lightweight local headline browser offers **Read full article** buttons that open publisher pages in the default browser, respecting subscriptions and without scraping or copying article bodies.
- Enabled on-demand feed refresh in the new headline screen even without a home-screen news widget. Kept the ~30-minute shared background RSS schedule optional, independent from weather refreshes.
- Migrated existing section preferences to v3 while preserving deliberately disabled sections and the all-off choice.

## v1.3 – Selective The Hindu news
- Replaced the India-only RSS stream with three user-selectable feeds: Science, World/International, and Home/Top Stories. Top Stories is deliberately not described as the printed newspaper's actual Page One.
- Added checkboxes in the app configuration screen, default all selected. Category-only changes do not require city lookup.
- Fetches selected sections only, fairly interleaves and deduplicates up to 12 headlines, and labels each in the rotating widget.
- Cancels RSS polling when all sections are disabled, preserves successful feed results if another section fails, and filters old cache entries by selection.
- Preserved weather, AQI, precipitation, sky widget, Quick Settings and status-bar icons.

## v1.2 – The Hindu weather-and-news widget
- Added optional 4×2 Weather + Headlines widget with existing Open-Meteo temperature, icon and city, plus a rotating The Hindu India RSS headline strip.
- Added isolated 30-minute JobScheduler RSS updates, capped on-device headline/link/date cache, publisher-only HTTPS link validation, no extra libraries and no full article copying.
- Added collection-capable AdapterViewFlipper with modern `RemoteCollectionItems` on Android 12+ and RemoteViewsService fallback on Android 8–11.
- Preserved the five original weather/AQI/rain/sky widgets and Quick Settings weather status icons.
- Modernized GitHub build workflow to work with the uploaded ZIP and existing Android SDK, avoiding the retired `tools` package.


## v1.1.1 – Revised user temperature ranges
- Updated the status-bar icon thresholds to the user-requested mapping: ≤0°C bundled-up person, 1–7°C two snowflakes, 8–13°C one snowflake, 14–20°C sun/cloud, 21–27°C simple thermometer, 28–33°C simple thermometer fallback, 34–38°C sweating person, ≥39°C red hot flame.
- Resolved the overlap between “0°C and below” and “0–7°C” by interpreting them as `≤0°C` and `1–7°C`.
- Kept thunderstorm and rain icons as higher-priority condition overrides.

## v1.1 – Condition-aware status bar icons
- Replaced numeric glyph (`27°`) with exactly one condition/temperature icon from the nine uploaded user images.
- Added white/transparent, density-specific 24/36/48/72/96 px status bar assets, and full-color artwork for the notification drawer.
- Mapped Open-Meteo weather codes to precipitation/storm/cold/hot categories, with bad weather taking priority over comfort temperature.
- Fahrenheit-aware numeric thresholds (defined in °C), and status-bar icons refreshed from the existing weather cache with no additional weather polling.
- Updated the Quick Settings tile icon to match the status icon and preserved its on/off semantics and notification permission handling.
- Original uploaded filenames containing thresholds were not retained by the attachment system. Current default thresholds are documented in README and editable in WeatherStatusIcons.java.

## v1.0 – Widget pack / Quick Settings tile
- Five home-screen widgets: compact weather, four-hour forecast, US AQI, six-hour precipitation, sun/moon sky arcs.
- Toggleable Quick Settings temperature icon and battery-friendly shared weather updates.
