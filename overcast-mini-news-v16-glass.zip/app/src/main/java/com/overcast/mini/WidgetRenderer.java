package com.overcast.mini;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.net.Uri;
import android.os.Build;
import java.util.List;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;
import java.util.Locale;

/**
 * Renders both Overcast-styled Material 3 Expressive widgets purely from cached data.
 */
public final class WidgetRenderer {
    public static final String ACTION_REFRESH = "com.overcast.mini.ACTION_REFRESH";

    private static final int[] HOUR_TIME_IDS = { R.id.h0_time, R.id.h1_time, R.id.h2_time, R.id.h3_time };
    private static final int[] HOUR_ICON_IDS = { R.id.h0_icon, R.id.h1_icon, R.id.h2_icon, R.id.h3_icon };
    private static final int[] HOUR_TEMP_IDS = { R.id.h0_temp, R.id.h1_temp, R.id.h2_temp, R.id.h3_temp };

    private WidgetRenderer() {}

    public static void updateAll(Context context) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(context);
        int[] compactIds = mgr.getAppWidgetIds(new ComponentName(context, OvercastWidgetProvider.class));
        for (int id : compactIds) {
            mgr.updateAppWidget(id, buildViews(context, false));
        }
        int[] forecastIds = mgr.getAppWidgetIds(new ComponentName(context, OvercastForecastWidgetProvider.class));
        for (int id : forecastIds) {
            mgr.updateAppWidget(id, buildViews(context, true));
        }
        int[] aqiIds = mgr.getAppWidgetIds(new ComponentName(context, OvercastAqiWidgetProvider.class));
        for (int id : aqiIds) mgr.updateAppWidget(id, buildAirQualityViews(context));
        int[] rainIds = mgr.getAppWidgetIds(new ComponentName(context, OvercastPrecipWidgetProvider.class));
        for (int id : rainIds) mgr.updateAppWidget(id, buildPrecipViews(context));
        updateSky(context);
        updateNews(context);
    }

    /** Refresh news content from SharedPreferences only. No network calls on widget redraw. */
    public static void updateNews(Context context) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(context);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(context, OvercastNewsWidgetProvider.class));
        for (int id : ids) mgr.updateAppWidget(id, buildNewsViews(context, id));
        if (ids.length > 0) mgr.notifyAppWidgetViewDataChanged(ids, R.id.news_flipper);
    }

    public static RemoteViews buildHeadlineItem(Context context, NewsFeedClient.Headline headline) {
        RemoteViews item = new RemoteViews(context.getPackageName(), R.layout.news_headline_item);
        item.setTextViewText(R.id.news_item_title, headline.title);
        Intent fillIn = new Intent();
        fillIn.putExtra(NewsLinkActivity.EXTRA_URL, headline.url);
        item.setOnClickFillInIntent(R.id.news_item_root, fillIn);
        return item;
    }

    private static RemoteViews buildNewsViews(Context context, int appWidgetId) {
        boolean glass = WeatherPrefs.isGlassModeEnabled(context);
        RemoteViews rv = new RemoteViews(context.getPackageName(), glass
                ? R.layout.widget_overcast_news_glass : R.layout.widget_overcast_news);
        if (glass) WeatherScene.apply(context, rv);
        String city = WeatherPrefs.getCity(context);
        rv.setTextViewText(R.id.city_pill, city.isEmpty() ? "Set city" : city);
        WeatherData weather = WeatherData.parse(WeatherPrefs.getCachedJson(context));
        if (weather == null) {
            rv.setTextViewText(R.id.news_weather_temp, "--°");
            rv.setTextViewText(R.id.news_weather_condition, "Weather · Headlines");
            rv.setImageViewResource(R.id.news_weather_icon, R.drawable.ic_w_cloudy);
        } else {
            rv.setTextViewText(R.id.news_weather_temp, weather.temp + "°");
            rv.setTextViewText(R.id.news_weather_condition,
                    WeatherData.conditionLabel(weather.wmoCode));
            rv.setImageViewResource(R.id.news_weather_icon,
                    WeatherData.iconRes(weather.wmoCode, weather.isDay));
        }
        Intent config = new Intent(context, ConfigActivity.class);
        PendingIntent cityPi = PendingIntent.getActivity(context, 3, config,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.city_pill, cityPi);

        Intent refresh = new Intent(context, OvercastNewsWidgetProvider.class);
        refresh.setAction(ACTION_REFRESH);
        PendingIntent refreshPi = PendingIntent.getBroadcast(context, 71, refresh,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.news_weather_block, refreshPi);

        Intent browse = new Intent(context, NewsBrowseActivity.class);
        PendingIntent browsePi = PendingIntent.getActivity(context, 76, browse,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.news_browse, browsePi);

        // A collection template is required: every RSS headline has its own URL.
        Intent openItem = new Intent(context, NewsLinkActivity.class);
        int flag = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 31) flag |= PendingIntent.FLAG_MUTABLE;
        PendingIntent openPi = PendingIntent.getActivity(context, 72, openItem, flag);
        rv.setPendingIntentTemplate(R.id.news_flipper, openPi);
        rv.setEmptyView(R.id.news_flipper, R.id.news_empty);
        int selected = NewsCategories.selected(context);
        List<NewsFeedClient.Headline> items = NewsStore.read(context);
        String enabledSource = (selected & NewsCategories.HINDU_ALL) == 0
                ? "THE INDIAN EXPRESS"
                : ((selected & NewsCategories.EXPRESS_ALL) == 0
                    ? "THE HINDU" : "THE HINDU + INDIAN EXPRESS");
        if (selected == 0) {
            rv.setTextViewText(R.id.news_source, "NEWS · PAUSED");
            rv.setTextViewText(R.id.news_empty, "Select a news section in Overcast Mini settings");
        } else if (items.isEmpty()) {
            rv.setTextViewText(R.id.news_source, enabledSource);
            rv.setTextViewText(R.id.news_empty, "No headlines yet · tap weather to refresh");
        } else {
            long age = Math.max(0L, System.currentTimeMillis() - NewsStore.updatedAt(context));
            rv.setTextViewText(R.id.news_source, age >= 6 * 3_600_000L
                    ? "NEWS · CACHED HEADLINES"
                    : enabledSource);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            RemoteViews.RemoteCollectionItems.Builder collection =
                    new RemoteViews.RemoteCollectionItems.Builder();
            for (int i = 0; i < items.size(); i++)
                collection.addItem(i, buildHeadlineItem(context, items.get(i)));
            rv.setRemoteAdapter(R.id.news_flipper, collection.build());
        } else {
            Intent svc = new Intent(context, NewsRemoteViewsService.class);
            svc.setData(Uri.parse("overcastnews://headlines/" + appWidgetId));
            rv.setRemoteAdapter(R.id.news_flipper, svc);
        }
        return rv;
    }

    /** Astronomy redraw is fully offline: used by the 30-minute sky-only update. */
    public static void updateSky(Context context) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(context);
        int[] skyIds = mgr.getAppWidgetIds(new ComponentName(context, OvercastSkyWidgetProvider.class));
        for (int id : skyIds) mgr.updateAppWidget(id, buildSkyViews(context));
    }

    private static RemoteViews simpleViews(Context c, int layout, Class<?> provider, int requestCode) {
        boolean glass = WeatherPrefs.isGlassModeEnabled(c);
        int actualLayout = glass ? WeatherScene.glassLayout(layout) : layout;
        RemoteViews rv = new RemoteViews(c.getPackageName(), actualLayout);
        if (glass) WeatherScene.apply(c, rv);
        Intent intent = new Intent(c, provider);
        intent.setAction(ACTION_REFRESH);
        PendingIntent pi = PendingIntent.getBroadcast(c, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.widget_root, pi);
        Intent config = new Intent(c, ConfigActivity.class);
        config.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent configPi = PendingIntent.getActivity(c, 3, config,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.city_pill, configPi);
        return rv;
    }

    private static String city(Context c) {
        String city = WeatherPrefs.getCity(c);
        return city.isEmpty() ? "Set city" : city;
    }

    public static RemoteViews buildAirQualityViews(Context c) {
        RemoteViews rv = simpleViews(c, R.layout.widget_overcast_aqi,
                OvercastAqiWidgetProvider.class, 4);
        rv.setTextViewText(R.id.aqi_city, city(c));
        AirQualityData d = AirQualityData.parse(WeatherPrefs.getAirQualityJson(c));
        if (d == null) {
            rv.setTextViewText(R.id.aqi_value, "--");
            rv.setTextViewText(R.id.aqi_category, "No data");
            rv.setTextViewText(R.id.aqi_pm25, "PM2.5 --");
            rv.setTextViewText(R.id.aqi_pm10, "PM10 --");
            rv.setTextViewText(R.id.aqi_updated, "Connect to load · CAMS/Open-Meteo");
            return rv;
        }
        rv.setTextViewText(R.id.aqi_value, Integer.toString(d.usAqi));
        rv.setTextViewText(R.id.aqi_category, d.label());
        rv.setTextColor(R.id.aqi_category, d.categoryColor());
        rv.setTextViewText(R.id.aqi_pm25, "PM2.5 " + AirQualityData.pollutantLabel(d.pm25));
        rv.setTextViewText(R.id.aqi_pm10, "PM10 " + AirQualityData.pollutantLabel(d.pm10));
        long age = Math.max(0L, System.currentTimeMillis() - WeatherPrefs.getAirQualityUpdatedMs(c));
        long hours = age / 3_600_000L;
        String ageText = age < 3_600_000 ? "Updated <1h ago" : "Updated " + hours + "h ago";
        if (hours >= 6) ageText = "Stale · " + hours + "h old";
        rv.setTextViewText(R.id.aqi_updated, ageText + " · µg/m³ · CAMS");
        return rv;
    }

    public static RemoteViews buildPrecipViews(Context c) {
        RemoteViews rv = simpleViews(c, R.layout.widget_overcast_precip,
                OvercastPrecipWidgetProvider.class, 5);
        rv.setTextViewText(R.id.rain_city, city(c));
        WeatherData d = WeatherData.parse(WeatherPrefs.getCachedJson(c));
        if (d == null || d.rainHourCount == 0) {
            rv.setTextViewText(R.id.rain_total, "-- mm");
            rv.setTextViewText(R.id.rain_peak, "Forecast unavailable");
            rv.setViewVisibility(R.id.rain_graph, View.GONE);
            return rv;
        }
        rv.setViewVisibility(R.id.rain_graph, View.VISIBLE);
        String total = d.rainTotalMm < 0.05 ? "0 mm" :
                (d.rainTotalMm < 10 ? String.format(Locale.US, "%.1f mm", d.rainTotalMm)
                        : Math.round(d.rainTotalMm) + " mm");
        rv.setTextViewText(R.id.rain_total, total);
        rv.setTextViewText(R.id.rain_peak, "Peak chance " + d.rainPeakChance + "%");
        rv.setImageViewBitmap(R.id.rain_graph, MiniCharts.precipitation(c, d));
        return rv;
    }

    public static RemoteViews buildSkyViews(Context c) {
        RemoteViews rv = simpleViews(c, R.layout.widget_overcast_sky,
                OvercastSkyWidgetProvider.class, 6);
        rv.setTextViewText(R.id.sky_city, city(c));
        if (!WeatherPrefs.hasLocation(c)) {
            rv.setTextViewText(R.id.sky_sun_position, "☀ Sun --°");
            rv.setTextViewText(R.id.sky_moon_position, "☾ Moon --°");
            rv.setTextViewText(R.id.sky_times, "Choose a city for sunrise & sunset");
            rv.setTextViewText(R.id.sky_moon_times, "☾ Rise --:--    Set --:--");
            rv.setTextViewText(R.id.sky_phase, "Moon phase --");
            rv.setViewVisibility(R.id.sky_horizon, View.GONE);
            return rv;
        }
        WeatherData weather = WeatherData.parse(WeatherPrefs.getCachedJson(c));
        SkyTimeline timeline = SkyTimeline.calculate(WeatherPrefs.getLat(c), WeatherPrefs.getLon(c),
                System.currentTimeMillis(), weather);
        rv.setTextViewText(R.id.sky_sun_position, "☀ Sun " + Math.round(timeline.now.sun.altitude)
                + "° " + (timeline.now.sun.altitude >= 0 ? "above" : "below") + " horizon");
        rv.setTextViewText(R.id.sky_moon_position, "☾ Moon " + Math.round(timeline.now.moon.altitude)
                + "° " + (timeline.now.moon.altitude >= 0 ? "up" : "down"));
        rv.setTextViewText(R.id.sky_times,
                "☀ Sunrise " + timeline.sunrise + "     Sunset " + timeline.sunset);
        rv.setTextViewText(R.id.sky_moon_times,
                "☾ Rise " + timeline.moonrise + "    Set " + timeline.moonset);
        rv.setTextViewText(R.id.sky_phase, timeline.now.moonPhase
                + " · " + timeline.now.moonIllumination + "%");
        rv.setViewVisibility(R.id.sky_horizon, View.VISIBLE);
        rv.setImageViewBitmap(R.id.sky_horizon, MiniCharts.sky(c, timeline));
        return rv;
    }

    public static RemoteViews buildViews(Context context, boolean withHourly) {
        int layout = withHourly ? R.layout.widget_overcast_forecast : R.layout.widget_overcast_compact;
        boolean glass = WeatherPrefs.isGlassModeEnabled(context);
        RemoteViews rv = new RemoteViews(context.getPackageName(),
                glass ? WeatherScene.glassLayout(layout) : layout);
        if (glass) WeatherScene.apply(context, rv);

        // Tap temperature/card to refresh; tap city pill to open config
        Intent refreshIntent = new Intent(context,
                withHourly ? OvercastForecastWidgetProvider.class : OvercastWidgetProvider.class);
        refreshIntent.setAction(ACTION_REFRESH);
        PendingIntent refreshPi = PendingIntent.getBroadcast(
                context, withHourly ? 2 : 1, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.widget_root, refreshPi);

        Intent cfgIntent = new Intent(context, ConfigActivity.class);
        cfgIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent cfgPi = PendingIntent.getActivity(
                context, 3, cfgIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.city_pill, cfgPi);

        String city = WeatherPrefs.getCity(context);
        WeatherData d = WeatherData.parse(WeatherPrefs.getCachedJson(context));

        if (d == null) {
            rv.setTextViewText(R.id.tv_city, city.isEmpty() ? "Tap to set city" : city);
            rv.setTextViewText(R.id.tv_temp, "--°");
            rv.setTextViewText(R.id.tv_condition, "Overcast Mini");
            rv.setTextViewText(R.id.tv_hl, "H:--°  L:--°");
            rv.setViewVisibility(R.id.tv_rain_pill, View.GONE);
            rv.setImageViewResource(R.id.iv_icon, R.drawable.ic_w_cloudy);
            if (withHourly) {
                rv.setViewVisibility(R.id.hourly_pill, View.GONE);
            }
            return rv;
        }

        rv.setTextViewText(R.id.tv_city, city.isEmpty() ? "Weather" : city);
        rv.setTextViewText(R.id.tv_temp, d.temp + "°");
        rv.setTextViewText(R.id.tv_condition, WeatherData.conditionLabel(d.wmoCode));
        rv.setTextViewText(R.id.tv_hl, "H:" + d.high + "°  L:" + d.low + "°");
        rv.setImageViewResource(R.id.iv_icon, WeatherData.iconRes(d.wmoCode, d.isDay));

        if (d.precipProb > 0) {
            rv.setViewVisibility(R.id.tv_rain_pill, View.VISIBLE);
            rv.setTextViewText(R.id.tv_rain_pill, d.precipProb + "%");
        } else {
            rv.setViewVisibility(R.id.tv_rain_pill, View.GONE);
        }

        if (withHourly) {
            if (d.hourCount > 0) {
                rv.setViewVisibility(R.id.hourly_pill, View.VISIBLE);
                for (int i = 0; i < 4; i++) {
                    if (i < d.hourCount) {
                        rv.setTextViewText(HOUR_TIME_IDS[i], d.hourLabels[i]);
                        rv.setImageViewResource(HOUR_ICON_IDS[i], WeatherData.iconRes(d.hourCodes[i], d.isDay));
                        rv.setTextViewText(HOUR_TEMP_IDS[i], d.hourTemps[i] + "°");
                    }
                }
            } else {
                rv.setViewVisibility(R.id.hourly_pill, View.GONE);
            }
        }
        return rv;
    }
}
